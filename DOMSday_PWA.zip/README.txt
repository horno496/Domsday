DOMSday

Installable Progressive Web App (PWA)
Tagline: Track. Lift. Regret it tomorrow.

INSTALL ON IPHONE
1. Upload this folder to an HTTPS host such as GitHub Pages, Netlify, or Cloudflare Pages.
2. Open the hosted URL in Safari.
3. Tap Share.
4. Tap Add to Home Screen.
5. Open DOMSday from the home-screen icon.

The app stores your weekly workout data locally on the phone.
Once installed and successfully opened, it can work offline using the service worker.

IMPORTANT
Deleting Safari/site data can erase workout history stored locally on the device.
